# Benoetigte Module werden importiert und eingerichtet
import RPi.GPIO as GPIO
import time
   
GPIO.setmode(GPIO.BCM)
   
# Hier werden die beiden Pins deklariert, an dem der Sensor und die LED angeschlossen sind,
LED_PIN = 24
Sensor_PIN = 23
GPIO.setup(Sensor_PIN, GPIO.IN)
GPIO.setup(LED_PIN, GPIO.OUT)
   
print("Sensor-Test [druecken Sie STRG+C, um den Test zu beenden]")
   
# Diese AusgabeFunktion wird bei Signaldetektion ausgefuehrt
def ausgabeFunktion(null):
        GPIO.output(LED_PIN, True)
   
# Beim Detektieren eines Signals wird die Ausgabefunktion ausgeloest
GPIO.add_event_detect(Sensor_PIN, GPIO.FALLING, callback=ausgabeFunktion, bouncetime=10) 
   
# Hauptprogrammschleife
try:
    while True:
        time.sleep(1)
        #Ausgang wird wieder zurueckgesetzt, falls der Neigungschalter wieder auf die andere Seite geneigt wird
        if GPIO.input(Sensor_PIN):
            GPIO.output(LED_PIN,False)
   
# Aufraeumarbeiten nachdem das Programm beendet wurde
except KeyboardInterrupt:
        GPIO.cleanup()