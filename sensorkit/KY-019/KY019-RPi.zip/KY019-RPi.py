# Benoetigte Module werden importiert und eingerichtet
import RPi.GPIO as GPIO
import time
 
GPIO.setmode(GPIO.BCM)
# Hier wird die Pause (in Sekunden) zwischen dem Umschalten deklariert
delayTime = 1
 
# Hier wird der Eingangs-Pin deklariert, an dem der Sensor angeschlossen ist. Zusaetzlich wird auch der PullUP Widerstand am Eingang aktiviert
RELAIS_PIN = 24
GPIO.setup(RELAIS_PIN, GPIO.OUT)
GPIO.output(RELAIS_PIN, False)
 
print ("Sensor-Test [druecken Sie STRG+C, um den Test zu beenden]")
 
 
# Hauptprogrammschleife
try:
    while True:
        GPIO.output(RELAIS_PIN, True) # NO ist nun kurzgeschlossen
        time.sleep(delayTime)
        GPIO.output(RELAIS_PIN, False) # NC ist nun kurzgeschlossen
        time.sleep(delayTime)
 
# Aufraeumarbeiten nachdem das Programm beendet wurde
except KeyboardInterrupt:
        GPIO.cleanup()