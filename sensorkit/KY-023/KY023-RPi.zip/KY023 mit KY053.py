#!/usr/bin/python
# coding=utf-8
 
#############################################################################################################
### Copyright by Joy-IT
### Published under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
### Commercial use only after permission is requested and granted
###
### KY-053 Analog Digital Converter - Raspberry Pi Python Code Example
###
#############################################################################################################
import time
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

Button_PIN = 24
GPIO.setup(Button_PIN, GPIO.IN, pull_up_down = GPIO.PUD_UP)

delayTime = 0.2
# Create the I2C bus
i2c = busio.I2C(board.SCL, board.SDA)

# Create the ADC object using the I2C bus
ads = ADS.ADS1115(i2c)

# Create single-ended input on channels
chan0 = AnalogIn(ads, ADS.P0)
chan1 = AnalogIn(ads, ADS.P1)
chan2 = AnalogIn(ads, ADS.P2)
chan3 = AnalogIn(ads, ADS.P3)


while True:
    #Aktuelle Werte werden aufgenommen
    x = '%.2f' % chan0.voltage
    y = '%.2f' % chan1.voltage
 
    # Ausgabe auf die Konsole
    if GPIO.input(Button_PIN) == True:
        print ("X-Achse:", x,"V, ","Y-Achse:", y,"V, Button: nicht gedrÃ¼ckt")
    else:
        print ("X-Achse:", x, "V, ", "Y-Achse:", y, "V, Button: gedrÃ¼ckt")
        print ("---------------------------------------")
 
        # Reset + Delay
        button_pressed = False
        time.sleep(delayTime)